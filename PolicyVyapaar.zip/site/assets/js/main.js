// ===== Policy Vyapaar — shared behaviour =====

document.addEventListener('DOMContentLoaded', () => {
  initNavToggle();
  initCarousel();
  initCountUp();
  initReveal();
  initForms();
});

/* ---------- Mobile nav ---------- */
function initNavToggle() {
  const toggle = document.querySelector('.nav-toggle');
  const links = document.querySelector('.nav-links');
  if (!toggle || !links) return;
  toggle.addEventListener('click', () => {
    const open = links.classList.toggle('is-open');
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  links.querySelectorAll('a').forEach((a) =>
    a.addEventListener('click', () => links.classList.remove('is-open'))
  );
}

/* ---------- Hero carousel ---------- */
function initCarousel() {
  const root = document.querySelector('[data-carousel]');
  if (!root) return;
  const track = root.querySelector('.carousel-track');
  const slides = Array.from(root.querySelectorAll('.carousel-slide'));
  const dotsWrap = root.querySelector('.carousel-dots');
  const prevBtn = root.querySelector('[data-prev]');
  const nextBtn = root.querySelector('[data-next]');
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let index = 0;
  let timer = null;

  slides.forEach((_, i) => {
    const dot = document.createElement('button');
    dot.className = 'carousel-dot' + (i === 0 ? ' is-active' : '');
    dot.setAttribute('aria-label', 'Go to slide ' + (i + 1));
    dot.addEventListener('click', () => goTo(i));
    dotsWrap.appendChild(dot);
  });
  const dots = Array.from(dotsWrap.children);

  function render() {
    track.style.transform = `translateX(-${index * 100}%)`;
    dots.forEach((d, i) => d.classList.toggle('is-active', i === index));
  }
  function goTo(i) {
    index = (i + slides.length) % slides.length;
    render();
  }
  function next() { goTo(index + 1); }
  function prev() { goTo(index - 1); }
  function start() {
    if (reduceMotion) return;
    stop();
    timer = setInterval(next, 3000);
  }
  function stop() { if (timer) clearInterval(timer); }

  nextBtn?.addEventListener('click', () => { next(); start(); });
  prevBtn?.addEventListener('click', () => { prev(); start(); });
  root.addEventListener('mouseenter', stop);
  root.addEventListener('mouseleave', start);
  root.addEventListener('focusin', stop);
  root.addEventListener('focusout', start);

  render();
  start();
}

/* ---------- Count-up stats ---------- */
function initCountUp() {
  const els = document.querySelectorAll('[data-count-to]');
  if (!els.length) return;
  const animated = new WeakSet();

  function trigger(el) {
    if (animated.has(el)) return;
    animated.add(el);
    animateCount(el);
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        trigger(entry.target);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });
  els.forEach((el) => observer.observe(el));

  // Safety net: same reasoning as scroll-reveal above — never leave a stat
  // stuck at its starting value if the observer doesn't fire for any reason.
  window.setTimeout(() => els.forEach(trigger), 2200);
}
function animateCount(el) {
  const to = parseFloat(el.dataset.countTo);
  const suffix = el.dataset.suffix || '';
  const decimals = el.dataset.countTo.includes('.') ? 1 : 0;
  const duration = 1100;
  const start = performance.now();
  function step(now) {
    const progress = Math.min((now - start) / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    const value = to * eased;
    el.textContent = value.toFixed(decimals) + suffix;
    if (progress < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

/* ---------- Scroll reveal ---------- */
function initReveal() {
  const els = document.querySelectorAll('.reveal');
  if (!els.length) return;

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduceMotion) {
    els.forEach((el) => el.classList.add('is-visible'));
    return;
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -5% 0px' });
  els.forEach((el) => observer.observe(el));

  // Safety net: if for any reason an element never intersects (e.g. zero-height
  // parent at load, very short pages, or a browser quirk), never leave it stuck
  // invisible. Force-reveal anything still hidden shortly after load.
  window.setTimeout(() => {
    els.forEach((el) => el.classList.add('is-visible'));
  }, 1800);
}

/* ---------- Netlify-friendly AJAX form submit ---------- */
function initForms() {
  document.querySelectorAll('form[data-netlify-ajax]').forEach((form) => {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const status = form.querySelector('.form-status');
      const submitBtn = form.querySelector('button[type="submit"]');
      const originalLabel = submitBtn ? submitBtn.textContent : '';
      if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Sending...'; }

      const data = new FormData(form);
      try {
        const res = await fetch('/', { method: 'POST', body: data });
        if (!res.ok) throw new Error('Network response was not ok');
        form.reset();
        if (status) {
          status.textContent = "Thanks — we've got your details and will be in touch soon.";
          status.className = 'form-status is-success';
        }
      } catch (err) {
        if (status) {
          status.textContent = 'Something went wrong sending this. Please try again, or call us directly.';
          status.className = 'form-status is-error';
        }
      } finally {
        if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = originalLabel; }
      }
    });
  });
}
